﻿# iOS 18: Always Know The Time

Many of us rely on our smartphones to know the time, rather than a watch, but with phones running out of battery relatively fast there's always a risk that we'll be unable to see the time when it might be important, and with **iOS 18**, Apple has a partial solution to this problem.

[Learn More](https://www.techradar.com/phones/ios/ios-18-ensures-youll-always-know-the-time-even-when-your-iphone-15-is-out-of-battery?utm_source=WhatsApp&utm_medium=Social&utm_campaign=WhatsApp)
