document.addEventListener('DOMContentLoaded', () => {
    // Function to toggle dark mode
    const themeToggleBtn = document.getElementById('theme-toggle');
    const currentTheme = localStorage.getItem('theme') || 'light';

    if (currentTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggleBtn.textContent = '🌞'; // Emoji for sun
    } else {
        themeToggleBtn.textContent = '🌚'; // Emoji for moon
    }

    themeToggleBtn.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        const theme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
        localStorage.setItem('theme', theme);
        themeToggleBtn.textContent = theme === 'dark' ? '🌞' : '🌚';
    });

    // Slideshow functionality
    let slideIndex = 0;
    showSlides();

    function showSlides() {
        let slides = document.getElementsByClassName('slide');
        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = 'none';  // Hide all slides initially
        }
        slideIndex++;
        if (slideIndex > slides.length) { slideIndex = 1 }  // Loop to the beginning if end reached
        slides[slideIndex - 1].style.display = 'block';  // Display current slide
        setTimeout(showSlides, 3000); // Change image every 3 seconds
    }

    // Modal functionality
    const modal = document.getElementById('modal');
    const modalImg = document.getElementById('modal-image');
    const modalText = document.getElementById('modal-text');
    const span = document.getElementsByClassName('close')[0];

    document.querySelectorAll('.slide img').forEach(img => {
        img.onclick = function() {
            modal.style.display = 'block';  // Display modal on image click
            modalImg.src = this.src;
            modalText.innerHTML = this.getAttribute('data-story');
        }
    });

    span.onclick = function() {
        modal.style.display = 'none';  // Hide modal when close button clicked
    }

    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';  // Hide modal when clicked outside of it
        }
    }

    // Hamburger menu functionality
    const hamburger = document.querySelector('.hamburger');
    const nav = document.getElementById('nav');

    hamburger.addEventListener('click', () => {
        nav.style.display = nav.style.display === 'none' ? 'block' : 'none';  // Toggle nav display on hamburger click
    });

    // Close nav when clicking on a link
    nav.addEventListener('click', (event) => {
        if (event.target.tagName === 'A') {
            nav.style.display = 'none';
        }
    });

    // Search functionality
    const searchInput = document.querySelector('.search-container input');
    const searchButton = document.querySelector('.search-container button');
    const searchResultsContainer = document.getElementById('search-results');

    searchButton.addEventListener('click', () => {
        const query = searchInput.value.trim().toLowerCase();
        if (query) {
            searchContent(query);
        }
    });

    function searchContent(query) {
        const articles = document.querySelectorAll('article');
        let resultsFound = false;
        searchResultsContainer.innerHTML = '';  // Clear previous search results

        articles.forEach(article => {
            const title = article.querySelector('h2').textContent.toLowerCase();
            const content = article.textContent.toLowerCase();

            if (title.includes(query) || content.includes(query)) {
                resultsFound = true;
                const resultItem = document.createElement('div');
                resultItem.classList.add('search-result-item');
                resultItem.innerHTML = `<p>${article.querySelector('h2').textContent}</p>`;
                resultItem.addEventListener('click', () => {
                    // Scroll to the article when clicked
                    article.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    // Clear search results
                    searchResultsContainer.innerHTML = '';
                });
                searchResultsContainer.appendChild(resultItem);
            }
        });

        if (!resultsFound) {
            searchResultsContainer.innerHTML = '<p>No results found.</p>';  // Display message if no results found
        }
    }

    // Comment section functionality
    const commentForm = document.getElementById('comment-form');
    const commentInput = document.getElementById('comment-input');
    const commentsContainer = document.getElementById('comments-container');

    let comments = JSON.parse(localStorage.getItem('comments')) || [];

    displayComments();

    commentForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const commentText = commentInput.value.trim();
        if (commentText) {
            const comment = {
                text: commentText,
                timestamp: new Date().toLocaleString()
            };
            comments.push(comment);
            localStorage.setItem('comments', JSON.stringify(comments));
            commentInput.value = '';
            displayComments();
        }
    });

    function displayComments() {
        commentsContainer.innerHTML = '';
        comments.forEach(comment => {
            const commentElement = document.createElement('div');
            commentElement.classList.add('comment');
            commentElement.innerHTML = `<p>${comment.text}</p><small>${comment.timestamp}</small>`;
            commentsContainer.appendChild(commentElement);
        });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    // Existing code...

    // Reply functionality
    commentsContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('reply-link')) {
            const parentComment = event.target.closest('.comment');
            const replyForm = document.createElement('form');
            replyForm.classList.add('reply-form');
            replyForm.innerHTML = `
                <textarea class="reply-input" placeholder="Reply to this comment..." required></textarea>
                <button type="submit">Post Reply</button>
            `;
            parentComment.querySelector('.replies-container').appendChild(replyForm);

            replyForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const replyInput = replyForm.querySelector('.reply-input').value.trim();
                if (replyInput) {
                    const reply = {
                        text: replyInput,
                        timestamp: new Date().toLocaleString()
                    };
                    if (!comments[parentComment.dataset.index].replies) {
                        comments[parentComment.dataset.index].replies = [];
                    }
                    comments[parentComment.dataset.index].replies.push(reply);
                    localStorage.setItem('comments', JSON.stringify(comments));
                    displayComments();
                    replyForm.remove();
                }
            });
        }
    });

    function displayComments() {
        commentsContainer.innerHTML = '';
        comments.forEach((comment, index) => {
            const commentElement = document.createElement('div');
            commentElement.classList.add('comment');
            commentElement.dataset.index = index;
            commentElement.innerHTML = `
                <p>${comment.text}</p>
                <small>${comment.timestamp}</small>
                <a href="#" class="reply-link">Reply</a>
                <div class="replies-container">
                    ${comment.replies ? comment.replies.map(reply => `
                        <div class="reply">
                            <p>${reply.text}</p>
                            <small>${reply.timestamp}</small>
                        </div>
                    `).join('') : ''}
                </div>
            `;
            commentsContainer.appendChild(commentElement);
        });
    }
});


  function addComment(postId) {
    const commentInput = document.getElementById(`comment-input-${postId}`);
    const commentText = commentInput.value.trim();
    if (commentText === "") return;

    const commentContainer = document.getElementById(`comments-${postId}`);

    const commentElement = document.createElement("div");
    commentElement.classList.add("comments");

    const commentTextElement = document.createElement("p");
    commentTextElement.textContent = commentText;

    const commentActions = document.createElement("div");
    commentActions.classList.add("comment-actions");

    const replyButton = document.createElement("button");
    replyButton.textContent = "Reply";
    replyButton.onclick = () => showReplyForm(commentElement);

    const likeButton = document.createElement("button");
    likeButton.textContent = "Like";
    likeButton.onclick = () => {
        likeButton.textContent = likeButton.textContent === "Like" ? "Liked" : "Like";
    };

    commentActions.appendChild(replyButton);
    commentActions.appendChild(likeButton);

    const repliesContainer = document.createElement("div");
    repliesContainer.classList.add("replies-container");

    commentElement.appendChild(commentTextElement);
    commentElement.appendChild(commentActions);
    commentElement.appendChild(repliesContainer);
    commentContainer.appendChild(commentElement);

    commentInput.value = "";
}

function showReplyForm(commentElement) {
    const replyForm = document.createElement("form");
    replyForm.classList.add("reply-form");

    const replyInput = document.createElement("textarea");
    replyInput.classList.add("comment-input");
    replyInput.placeholder = "Add a reply";

    const submitReplyButton = document.createElement("button");
    submitReplyButton.textContent = "Submit";
    submitReplyButton.type = "button";
    submitReplyButton.onclick = () => addReply(commentElement, replyInput.value);

    replyForm.appendChild(replyInput);
    replyForm.appendChild(submitReplyButton);

    commentElement.appendChild(replyForm);
}

function addReply(commentElement, replyText) {
    if (replyText.trim() === "") return;

    const repliesContainer = commentElement.querySelector(".replies-container");

    const replyElement = document.createElement("div");
    replyElement.classList.add("reply");

    const replyTextElement = document.createElement("p");
    replyTextElement.textContent = replyText;

    const replyInfo = document.createElement("small");
    replyInfo.textContent = "Replying to original comment";

    replyElement.appendChild(replyTextElement);
    replyElement.appendChild(replyInfo);

    repliesContainer.appendChild(replyElement);

    const replyForm = commentElement.querySelector(".reply-form");
    if (replyForm) {
        replyForm.remove();
    }
}

document.addEventListener('DOMContentLoaded', function() {
  const articleElement = document.getElementById('blog-content');

  // Fetch the content from content.html
  fetch('content.html')
    .then(response => response.text())
    .then(data => {
      // Set the innerHTML of <article> with the fetched content
      articleElement.innerHTML = data;
    })
    .catch(error => {
      console.error('Error fetching content:', error);
    });
});